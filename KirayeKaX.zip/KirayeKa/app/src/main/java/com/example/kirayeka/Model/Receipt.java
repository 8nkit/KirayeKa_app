package com.example.kirayeka.Model;

import java.util.List;

/**
 * Created by 123456 on 2017/11/27.
 */

public class Receipt {
    public List<Order> items;
    public String totalcost;
}
